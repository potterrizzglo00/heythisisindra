<?php include 'lib/koneksi.php'; ?>

<?php
$id = $_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM siswa WHERE id=?");
$stmt->execute([$id]);
$data = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Edit Data Siswa</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

<style>
    body {
        font-family: 'Poppins';
        background: linear-gradient(135deg, #4e73df, #6f42c1);
        height: 100vh; display: flex; justify-content: center; align-items: center;
    }

    .container {
        background: #fff; padding: 25px; width: 400px;
        border-radius: 15px; box-shadow: 0 10px 25px rgba(0,0,0,.15);
    }

    input { width: 100%; padding: 10px; margin-bottom: 15px; border-radius: 8px; border: 1px solid #bbb; }

    button {
        width: 100%; padding: 12px;
        background: #f6c23e; border: none; color: white;
        border-radius: 8px; font-size: 15px; cursor: pointer;
    }

    a { text-decoration: none; display: block; text-align: center; margin-top: 10px; }
</style>

</head>
<body>

<div class="container">
    <h2 style="text-align:center;color:#4e73df;">Edit Data</h2>

    <form method="POST">
        <input type="text" name="nama" value="<?= $data['nama']; ?>" required>
        <input type="text" name="kelas" value="<?= $data['kelas']; ?>" required>
        <input type="text" name="jurusan" value="<?= $data['jurusan']; ?>" required>

        <button name="update">Update</button>
    </form>

    <a href="tampil.php">Kembali</a>

    <?php
    if (isset($_POST['update'])) {
        $nama = $_POST['nama'];
        $kelas = $_POST['kelas'];
        $jurusan = $_POST['jurusan'];

        $update = $pdo->prepare("UPDATE siswa SET nama=?, kelas=?, jurusan=? WHERE id=?");
        $update->execute([$nama, $kelas, $jurusan, $id]);

        echo "<p style='color:green;text-align:center;'>Data berhasil diupdate!</p>";
        header("refresh:1; url=tampil.php");
    }
    ?>
</div>

</body>
</html>
