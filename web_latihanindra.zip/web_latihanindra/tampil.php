<?php include 'lib/koneksi.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Data Siswa</title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #6a5af9, #4e73df);
            margin: 0; padding: 0;
        }

        .container {
            max-width: 900px; margin: 60px auto; background: #fff;
            padding: 25px; border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0,0,0,.15);
            animation: fadeIn .7s ease;
        }

        h2 { text-align: center; color: #4e73df; margin-bottom: 20px; }

        .btn-add {
            display: inline-block; padding: 10px 15px;
            background: #1cc88a; color: white;
            text-decoration: none; border-radius: 8px;
            margin-bottom: 15px; transition: .3s;
        }
        .btn-add:hover { background: #17a673; transform: scale(1.05); }

        table { width: 100%; border-collapse: collapse; }

        thead tr { background: #4e73df; color: white; }

        th, td {
            padding: 12px; text-align: center;
            border-bottom: 1px solid #ddd;
        }

        tr:hover { background: #f3f4f6; }

        .btn-edit {
            padding: 6px 10px; background: #f6c23e;
            color: #fff; border-radius: 6px; text-decoration: none;
            margin-right: 5px;
        }

        .btn-delete {
            padding: 6px 10px; background: #e74a3b;
            color: #fff; border-radius: 6px; text-decoration: none;
        }

        .btn-delete:hover, .btn-edit:hover {
            opacity: .8;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to   { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>

<div class="container">

    <h2>Daftar Siswa</h2>

    <a href="tambah.php" class="btn-add">+ Tambah Data Siswa</a>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>Kelas</th>
                <th>Jurusan</th>
                <th>Aksi</th>
            </tr>
        </thead>

        <tbody>
        <?php
        $no = 1;
        $stmt = $pdo->query("SELECT * FROM siswa ORDER BY id DESC");

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "
            <tr>
                <td>{$no}</td>
                <td>{$row['nama']}</td>
                <td>{$row['kelas']}</td>
                <td>{$row['jurusan']}</td>
                <td>
                    <a class='btn-edit' href='edit.php?id={$row['id']}'>Edit</a>
                    <a class='btn-delete' 
                       href='delete.php?id={$row['id']}'
                       onclick='return confirm(\"Yakin ingin menghapus?\")'>
                       Delete
                    </a>
                </td>
            </tr>";
            $no++;
        }
        ?>
        </tbody>
    </table>

</div>

</body>
</html>
