<?php include 'lib/koneksi.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tambah Data Siswa</title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #4e73df, #6f42c1);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background: #fff;
            width: 400px;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.15);
            animation: fadeIn .7s ease;
        }

        h2 { text-align: center; color: #4e73df; margin-bottom: 20px; }

        label { font-weight: 500; }

        input[type="text"] {
            width: 100%; padding: 10px; margin-top: 5px;
            border: 1px solid #bbb; border-radius: 8px;
            margin-bottom: 15px; transition: .3s;
        }
        input[type="text"]:focus {
            border-color: #4e73df;
            box-shadow: 0 0 5px rgba(78,115,223,.4);
            outline: none;
        }

        button {
            width: 100%; padding: 12px;
            border: none; border-radius: 8px;
            background: #1cc88a; color: #fff;
            font-size: 15px; cursor: pointer; transition: .3s;
        }
        button:hover { background: #17a673; transform: scale(1.03); }

        .back-btn {
            display: block; text-align: center; margin-top: 10px;
            color: #6f42c1; text-decoration: none; font-weight: 600;
        }
        .alert {
            margin-top: 15px; background: #1cc88a; color: white;
            padding: 10px; border-radius: 8px; text-align: center;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to   { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Tambah Data Siswa</h2>

    <form method="POST">
        <label>Nama:</label>
        <input type="text" name="nama" required>

        <label>Kelas:</label>
        <input type="text" name="kelas" required>

        <label>Jurusan:</label>
        <input type="text" name="jurusan" required>

        <button type="submit" name="simpan">Simpan</button>
    </form>

    <a href="tampil.php" class="back-btn">← Kembali ke Data Siswa</a>

    <?php
    if (isset($_POST['simpan'])) {
        $nama = $_POST['nama'];
        $kelas = $_POST['kelas'];
        $jurusan = $_POST['jurusan'];

        $query = $pdo->prepare("INSERT INTO siswa (nama, kelas, jurusan) VALUES (?, ?, ?)");
        $query->execute([$nama, $kelas, $jurusan]);

        echo "<div class='alert'>Data berhasil disimpan!</div>";
        header("refresh:1; url=tampil.php");
    }
    ?>
</div>

</body>
</html>
